﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;


public partial class _Default : System.Web.UI.Page
{
    
    SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!Page.IsPostBack)
            {
                state();
                BindGridView();

            }
        }
        catch (Exception ex)
        {
            ShowMessage(ex.Message);
        }
    }
   

    void ShowMessage(string msg)
    {
        ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('" + msg + "');</script>");
    }
   
    void clear()
    {
        txtName.Text = string.Empty; txtAddress.Text = string.Empty; txtMobile.Text = string.Empty; txtEmail.Text = string.Empty;
        txtName.Focus();
        DDLSTATE.SelectedValue = "0";
        btnSubmit.Visible = true;
        btnUpdate.Visible = false;

    }
 
    private void BindGridView()
    {
        try
        {
            if (conn.State == ConnectionState.Closed)
            {
                conn.Open();
            }
            SqlCommand cmd = new SqlCommand("Select * from Student ORDER BY SID DESC;", conn);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            GridViewStudent.DataSource = ds;
            GridViewStudent.DataBind();
            
        }
        catch 
        {
            
        }
        finally
        {
            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
        }
    }
    public void state()
    {
        if (conn.State == ConnectionState.Closed)
        {
            conn.Open();
        }
        SqlCommand cmd = new SqlCommand("SELECT '0' as [sno],'--Seleate--' as [state] UNION SELECT [sno],[state]FROM [dbo].[state]", conn);
      SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        DDLSTATE.DataSource = dt;
        DDLSTATE.DataBind();
        DDLSTATE.DataTextField = "state";
        DDLSTATE.DataValueField = "sno";
        DDLSTATE.DataBind();
    }


    public string state_find(string state)
    {
        if (conn.State == ConnectionState.Closed)
        {
            conn.Open();
        }
        SqlCommand cmd = new SqlCommand("SELECT [state]FROM [dbo].[state] where [sno]="+ state, conn);
        SqlDataAdapter adp = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        adp.Fill(dt);
        state = dt.Rows[0]["state"].ToString();
        return state;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("Insert into student (Name,Address,Mobile,Email,STATE,Gender ) values (@Name,@Address,@Mobile,@Email,@STATE,@Gender)", conn);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("@STATE", DDLSTATE.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@Gender", rbEmpLevel.SelectedValue);
            cmd.ExecuteNonQuery();

            

            
            
            
            ShowMessage("Registered successfully......!");
            clear();
            BindGridView();
        }
        catch
        {
            
        }
        finally
        {
            conn.Close();
        }
    }

    
   
    protected void GridViewStudent_SelectedIndexChanged(object sender, EventArgs e)
    {
        GridViewRow row = GridViewStudent.SelectedRow;
        lblSID.Text = row.Cells[2].Text;
        txtName.Text = row.Cells[3].Text;
        txtAddress.Text = row.Cells[4].Text;
        txtEmail.Text = row.Cells[5].Text;
        txtMobile.Text = row.Cells[6].Text;
        DDLSTATE.SelectedValue = row.Cells[7].Text;
        rbEmpLevel.SelectedValue = row.Cells[8].Text;
        btnSubmit.Visible = false;
        btnUpdate.Visible = true;
    }
  
  
    protected void GridViewStudent_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            conn.Open();
            int SID = Convert.ToInt32(GridViewStudent.DataKeys[e.RowIndex].Value);
            SqlCommand cmd = new SqlCommand("Delete From student where SID='" + SID + "'", conn);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            ShowMessage("Student Data Delete Successfully......!");
            GridViewStudent.EditIndex = -1;
            BindGridView();
        }
        catch 
        {
           
        }
        finally
        {
            conn.Close();
        }
    }
 
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            conn.Open();
            string SID = lblSID.Text;
            SqlCommand cmd = new SqlCommand("update student Set Name=@Name,Address=@Address,Mobile=@Mobile,Email=@Email,STATE=@STATE ,Gender= @Gender where SID=@SID", conn);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Address", txtAddress.Text);
            cmd.Parameters.AddWithValue("@Mobile", txtMobile.Text);
            cmd.Parameters.AddWithValue("@Email", txtEmail.Text);
            cmd.Parameters.AddWithValue("SID", SID);
            cmd.Parameters.AddWithValue("@STATE", DDLSTATE.SelectedValue.ToString());
            cmd.Parameters.AddWithValue("@Gender", rbEmpLevel.SelectedValue);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            ShowMessage("Student Data update Successfully......!");
            GridViewStudent.EditIndex = -1;
            clear();
            BindGridView(); btnUpdate.Visible = false;
        }
        catch 
        {
           
        }
        finally
        {
            conn.Close();
        }
    }
    
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        clear();
    }
   
}