CREATE TABLE  student (  
 SID int NOT NULL  IDENTITY(1,1),  
 Name varchar(100) NOT NULL,  
 Address varchar(500) NOT NULL,  
 Email varchar(100) NOT NULL,  
 Mobile varchar(25) NOT NULL,  
 STATE VARCHAR(50) NOT NULL,
 Gender VARCHAR(10) NOT NULL
 PRIMARY KEY (SID)  
)  


CREATE TABLE [dbo].[state](
	[sno] [int] NULL,
	[state] [varchar](50) NULL
)


--DROP TABLE student

